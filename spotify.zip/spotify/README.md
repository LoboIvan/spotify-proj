### unsaon pag pa run
ayaw kalimot ug create ug database. ang pangan sa database kay spotify-chat  
pagkahumag create sa database e import ang spotify-chat.sql nga naa sa file
### frontend
```bash
open new terminal unya e run ni
cd frontend
npm install
npm run serve
```
### backend
```bash
open new terminal unya e run ni
cd backend
npm install
node index.js
```
### socket
```bash
open new terminal unya e run ni
cd socket
npm install
node index.js
```
